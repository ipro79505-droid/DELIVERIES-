package com.deliveries.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showWelcome()
    }

    private fun base(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(Color.WHITE)
        }
        return root
    }

    private fun title(text: String, size: Float = 28f): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.rgb(17,24,39))
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 10, 0, 18)
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            textSize = 16f
            setOnClickListener { action() }
            isAllCaps = false
        }

    private fun showWelcome() {
        base()
        root.gravity = Gravity.CENTER_HORIZONTAL
        val logo = title("DELIVERIES", 30f)
        logo.setTextColor(Color.rgb(37,99,235))
        root.addView(logo)
        root.addView(TextView(this).apply {
            text = "Fast. Safe. Delivered."
            textSize = 18f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }, LinearLayout.LayoutParams(-1, -2))
        Space(this).also { root.addView(it, LinearLayout.LayoutParams(1, 35)) }
        root.addView(button("Get Started") { showAccountType() },
            LinearLayout.LayoutParams(-1, 60))
        root.addView(button("Sign In") { showAccountType() },
            LinearLayout.LayoutParams(-1, 60))
        setContentView(root)
    }

    private fun showAccountType() {
        base()
        root.addView(title("Choose account"))
        root.addView(TextView(this).apply {
            text = "How will you use Deliveries?"
            textSize = 17f
            setTextColor(Color.DKGRAY)
        })
        root.addView(button("Customer") { showHome() },
            LinearLayout.LayoutParams(-1, 60))
        root.addView(button("Rider") { showRiderHome() },
            LinearLayout.LayoutParams(-1, 60))
        root.addView(button("Business") { showHome() },
            LinearLayout.LayoutParams(-1, 60))
        setContentView(root)
    }

    private fun showHome() {
        base()
        root.addView(title("Hello 👋"))
        root.addView(TextView(this).apply {
            text = "What would you like to do?"
            textSize = 18f
            setTextColor(Color.DKGRAY)
        })
        root.addView(button("📦  Send a package") { showCreateDelivery() },
            LinearLayout.LayoutParams(-1, 65))
        root.addView(button("🍔  Food delivery") { showCreateDelivery() },
            LinearLayout.LayoutParams(-1, 65))
        root.addView(button("🛍️  Shopping delivery") { showCreateDelivery() },
            LinearLayout.LayoutParams(-1, 65))
        root.addView(button("📍  Track delivery") { showTracking() },
            LinearLayout.LayoutParams(-1, 65))
        root.addView(button("My Deliveries") { showHistory() },
            LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun showCreateDelivery() {
        base()
        root.addView(title("Create delivery"))
        val pickup = EditText(this).apply { hint = "Pickup location" }
        val destination = EditText(this).apply { hint = "Destination" }
        val recipient = EditText(this).apply { hint = "Recipient name & phone" }
        val details = EditText(this).apply { hint = "Package details" }
        root.addView(pickup); root.addView(destination); root.addView(recipient); root.addView(details)
        root.addView(button("Continue") { showPrice() },
            LinearLayout.LayoutParams(-1, 60))
        setContentView(root)
    }

    private fun showPrice() {
        base()
        root.addView(title("Delivery price"))
        root.addView(TextView(this).apply {
            text = "Estimated distance: 6.4 km\nDelivery fee: UGX 8,000\nPlatform fee: UGX 1,000\n\nTOTAL: UGX 9,000"
            textSize = 19f
            setTextColor(Color.DKGRAY)
        })
        root.addView(button("Request Rider") { showFindingRider() },
            LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun showFindingRider() {
        base()
        root.addView(title("Finding a rider…"))
        root.addView(TextView(this).apply {
            text = "Your delivery request has been sent to nearby riders."
            textSize = 17f
            setTextColor(Color.DKGRAY)
        })
        root.addView(button("Simulate Rider Accepted") { showTracking() },
            LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun showTracking() {
        base()
        root.addView(title("Live delivery"))
        root.addView(TextView(this).apply {
            text = "📍 Rider is on the way\n\nPickup ✓\nDestination •\n\nRider: Demo Rider\nStatus: En route"
            textSize = 18f
            setTextColor(Color.DKGRAY)
        })
        root.addView(button("Confirm Delivery") { showCompleted() },
            LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun showCompleted() {
        base()
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(title("Delivery completed"))
        root.addView(TextView(this).apply {
            text = "Your package has been delivered successfully.\n\nThank you for using Deliveries!"
            textSize = 18f
            gravity = Gravity.CENTER
        })
        root.addView(button("Back to Home") { showHome() },
            LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun showHistory() {
        base()
        root.addView(title("My Deliveries"))
        root.addView(TextView(this).apply {
            text = "No completed deliveries yet.\n\nYour delivery history will appear here."
            textSize = 17f
            setTextColor(Color.DKGRAY)
        })
        root.addView(button("Back") { showHome() },
            LinearLayout.LayoutParams(-1, 60))
        setContentView(root)
    }

    private fun showRiderHome() {
        base()
        root.addView(title("Rider Home"))
        root.addView(TextView(this).apply {
            text = "Status: OFFLINE\n\nToday's earnings: UGX 0"
            textSize = 18f
            setTextColor(Color.DKGRAY)
        })
        root.addView(button("Go Online") { showRiderRequest() },
            LinearLayout.LayoutParams(-1, 65))
        root.addView(button("Earnings") { showRiderEarnings() },
            LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun showRiderRequest() {
        base()
        root.addView(title("New delivery"))
        root.addView(TextView(this).apply {
            text = "Pickup: Kampala\nDestination: Ntinda\nPackage: Small parcel\nEstimated earnings: UGX 8,000"
            textSize = 18f
        })
        root.addView(button("Accept") { showRiderDelivery() },
            LinearLayout.LayoutParams(-1, 65))
        root.addView(button("Reject") { showRiderHome() },
            LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun showRiderDelivery() {
        base()
        root.addView(title("Active delivery"))
        root.addView(TextView(this).apply {
            text = "Navigate to pickup\n\nPickup location: Kampala\nDestination: Ntinda"
            textSize = 18f
        })
        root.addView(button("Confirm Pickup") { showRiderComplete() },
            LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun showRiderComplete() {
        base()
        root.addView(title("Deliver package"))
        root.addView(TextView(this).apply {
            text = "Recipient: Demo Customer\nDestination: Ntinda"
            textSize = 18f
        })
        root.addView(button("Confirm Delivery") { showRiderHome() },
            LinearLayout.LayoutParams(-1, 65))
        setContentView(root)
    }

    private fun showRiderEarnings() {
        base()
        root.addView(title("Earnings"))
        root.addView(TextView(this).apply {
            text = "Today: UGX 8,000\nThis week: UGX 8,000\nAvailable balance: UGX 8,000"
            textSize = 18f
        })
        root.addView(button("Back") { showRiderHome() },
            LinearLayout.LayoutParams(-1, 60))
        setContentView(root)
    }
}
